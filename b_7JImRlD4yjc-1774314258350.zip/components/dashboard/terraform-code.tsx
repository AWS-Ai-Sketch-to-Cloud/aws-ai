"use client"

import { useState } from "react"
import { Copy, Check, Download, FileCode } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Empty } from "@/components/ui/empty"
import { ScrollArea } from "@/components/ui/scroll-area"

interface TerraformCodeProps {
  generationStatus: "idle" | "analyzing" | "complete" | "optimized"
}

const terraformCode = `# Sketch-to-Cloud 생성 Terraform 코드
# AWS 고가용성 웹 애플리케이션 인프라

terraform {
  required_version = ">= 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

# VPC 설정
resource "aws_vpc" "main" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = {
    Name        = "\${var.project_name}-vpc"
    Environment = var.environment
    ManagedBy   = "Sketch-to-Cloud"
  }
}

# 퍼블릭 서브넷 (AZ-1)
resource "aws_subnet" "public_az1" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.0.1.0/24"
  availability_zone       = "\${var.aws_region}a"
  map_public_ip_on_launch = true

  tags = {
    Name = "\${var.project_name}-public-az1"
    Type = "Public"
  }
}

# 퍼블릭 서브넷 (AZ-2)
resource "aws_subnet" "public_az2" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.0.2.0/24"
  availability_zone       = "\${var.aws_region}b"
  map_public_ip_on_launch = true

  tags = {
    Name = "\${var.project_name}-public-az2"
    Type = "Public"
  }
}

# Application Load Balancer
resource "aws_lb" "main" {
  name               = "\${var.project_name}-alb"
  internal           = false
  load_balancer_type = "application"
  security_groups    = [aws_security_group.alb.id]
  subnets           = [
    aws_subnet.public_az1.id,
    aws_subnet.public_az2.id
  ]

  tags = {
    Name        = "\${var.project_name}-alb"
    Environment = var.environment
  }
}

# Auto Scaling Group
resource "aws_autoscaling_group" "main" {
  name                = "\${var.project_name}-asg"
  vpc_zone_identifier = [
    aws_subnet.public_az1.id,
    aws_subnet.public_az2.id
  ]
  
  min_size         = 2
  max_size         = 10
  desired_capacity = 2

  launch_template {
    id      = aws_launch_template.main.id
    version = "$Latest"
  }

  tag {
    key                 = "Name"
    value               = "\${var.project_name}-instance"
    propagate_at_launch = true
  }
}

# RDS Multi-AZ
resource "aws_db_instance" "main" {
  identifier           = "\${var.project_name}-db"
  engine               = "mysql"
  engine_version       = "8.0"
  instance_class       = "db.t3.medium"
  allocated_storage    = 100
  storage_encrypted    = true
  multi_az             = true
  
  db_name  = var.db_name
  username = var.db_username
  password = var.db_password

  vpc_security_group_ids = [aws_security_group.rds.id]
  db_subnet_group_name   = aws_db_subnet_group.main.name

  backup_retention_period = 7
  skip_final_snapshot    = false
  final_snapshot_identifier = "\${var.project_name}-final-snapshot"

  tags = {
    Name        = "\${var.project_name}-rds"
    Environment = var.environment
  }
}

# S3 버킷
resource "aws_s3_bucket" "main" {
  bucket = "\${var.project_name}-assets-\${random_id.bucket.hex}"

  tags = {
    Name        = "\${var.project_name}-assets"
    Environment = var.environment
  }
}

# CloudFront 배포
resource "aws_cloudfront_distribution" "main" {
  enabled             = true
  default_root_object = "index.html"
  price_class         = "PriceClass_200"

  origin {
    domain_name = aws_lb.main.dns_name
    origin_id   = "alb"

    custom_origin_config {
      http_port              = 80
      https_port             = 443
      origin_protocol_policy = "https-only"
      origin_ssl_protocols   = ["TLSv1.2"]
    }
  }

  default_cache_behavior {
    allowed_methods        = ["GET", "HEAD", "OPTIONS", "PUT", "POST", "PATCH", "DELETE"]
    cached_methods         = ["GET", "HEAD"]
    target_origin_id       = "alb"
    viewer_protocol_policy = "redirect-to-https"
    compress               = true

    forwarded_values {
      query_string = true
      cookies {
        forward = "all"
      }
    }
  }

  restrictions {
    geo_restriction {
      restriction_type = "none"
    }
  }

  viewer_certificate {
    cloudfront_default_certificate = true
  }

  tags = {
    Name = "\${var.project_name}-cdn"
  }
}`

export function TerraformCode({ generationStatus }: TerraformCodeProps) {
  const [copied, setCopied] = useState(false)

  const copyToClipboard = async () => {
    await navigator.clipboard.writeText(terraformCode)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const downloadCode = () => {
    const blob = new Blob([terraformCode], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "main.tf"
    a.click()
    URL.revokeObjectURL(url)
  }

  if (generationStatus === "idle") {
    return (
      <div className="flex h-[600px] items-center justify-center">
        <Empty>
          <Empty.Icon>
            <FileCode className="h-10 w-10" strokeWidth={1} />
          </Empty.Icon>
          <Empty.Title>Terraform 코드</Empty.Title>
          <Empty.Description>
            아키텍처가 생성되면 배포 가능한
            <br />
            Terraform 코드가 자동으로 생성됩니다
          </Empty.Description>
        </Empty>
      </div>
    )
  }

  if (generationStatus === "analyzing") {
    return (
      <div className="flex h-[600px] items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="relative">
            <div className="h-16 w-16 animate-spin rounded-full border-2 border-muted border-t-primary" />
            <FileCode className="absolute left-1/2 top-1/2 h-6 w-6 -translate-x-1/2 -translate-y-1/2 text-primary" strokeWidth={1.5} />
          </div>
          <div className="text-center">
            <p className="text-sm font-medium text-foreground">코드 생성 중...</p>
            <p className="text-xs text-muted-foreground">Terraform 구성을 작성하고 있습니다</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="h-[600px] flex flex-col">
      <div className="flex items-center justify-between border-b border-border/30 px-4 py-2">
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-muted-foreground">main.tf</span>
          <span className="rounded bg-secondary/50 px-1.5 py-0.5 text-[10px] text-muted-foreground">
            HCL
          </span>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            className="h-7 px-2 text-xs text-muted-foreground hover:text-foreground"
            onClick={copyToClipboard}
          >
            {copied ? (
              <Check className="mr-1.5 h-3.5 w-3.5 text-success" strokeWidth={1.5} />
            ) : (
              <Copy className="mr-1.5 h-3.5 w-3.5" strokeWidth={1.5} />
            )}
            {copied ? "복사됨" : "복사"}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 px-2 text-xs text-muted-foreground hover:text-foreground"
            onClick={downloadCode}
          >
            <Download className="mr-1.5 h-3.5 w-3.5" strokeWidth={1.5} />
            다운로드
          </Button>
        </div>
      </div>
      <ScrollArea className="flex-1">
        <pre className="p-4 text-xs leading-relaxed">
          <code className="font-mono text-foreground/90">{terraformCode}</code>
        </pre>
      </ScrollArea>
    </div>
  )
}
