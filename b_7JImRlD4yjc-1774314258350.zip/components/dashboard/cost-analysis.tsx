"use client"

import { Receipt, TrendingDown, CheckCircle2, AlertCircle, ArrowRight } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Empty } from "@/components/ui/empty"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"

interface CostAnalysisProps {
  generationStatus: "idle" | "analyzing" | "complete" | "optimized"
}

const costData = {
  services: [
    {
      name: "EC2 Auto Scaling",
      description: "t3.large × 2 인스턴스 (On-Demand)",
      monthly: 121.44,
      optimized: 72.86,
      savings: "40%",
      recommendation: "예약 인스턴스 (1년) 권장",
    },
    {
      name: "RDS MySQL Multi-AZ",
      description: "db.t3.medium (100GB gp3)",
      monthly: 148.92,
      optimized: 89.35,
      savings: "40%",
      recommendation: "예약 인스턴스 (1년) 권장",
    },
    {
      name: "Application Load Balancer",
      description: "ALB + 처리 용량",
      monthly: 22.56,
      optimized: 22.56,
      savings: "0%",
      recommendation: null,
    },
    {
      name: "CloudFront CDN",
      description: "1TB 데이터 전송",
      monthly: 85.00,
      optimized: 85.00,
      savings: "0%",
      recommendation: null,
    },
    {
      name: "S3 Storage",
      description: "100GB Standard Storage",
      monthly: 2.30,
      optimized: 1.15,
      savings: "50%",
      recommendation: "S3 Intelligent-Tiering 권장",
    },
    {
      name: "Route 53",
      description: "호스팅 영역 + DNS 쿼리",
      monthly: 0.90,
      optimized: 0.90,
      savings: "0%",
      recommendation: null,
    },
    {
      name: "데이터 전송",
      description: "예상 아웃바운드 트래픽",
      monthly: 45.00,
      optimized: 45.00,
      savings: "0%",
      recommendation: null,
    },
  ],
  summary: {
    totalMonthly: 426.12,
    totalOptimized: 316.82,
    totalSavings: 109.30,
    savingsPercent: "25.6%",
  },
}

export function CostAnalysis({ generationStatus }: CostAnalysisProps) {
  if (generationStatus === "idle") {
    return (
      <div className="flex h-[600px] items-center justify-center">
        <Empty>
          <Empty.Icon>
            <Receipt className="h-10 w-10" strokeWidth={1} />
          </Empty.Icon>
          <Empty.Title>비용 분석</Empty.Title>
          <Empty.Description>
            아키텍처가 생성되면 상세한 비용 분석과
            <br />
            최적화 권장사항을 제공합니다
          </Empty.Description>
        </Empty>
      </div>
    )
  }

  if (generationStatus === "analyzing") {
    return (
      <div className="flex h-[600px] items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="relative">
            <div className="h-16 w-16 animate-spin rounded-full border-2 border-muted border-t-primary" />
            <Receipt className="absolute left-1/2 top-1/2 h-6 w-6 -translate-x-1/2 -translate-y-1/2 text-primary" strokeWidth={1.5} />
          </div>
          <div className="text-center">
            <p className="text-sm font-medium text-foreground">비용 분석 중...</p>
            <p className="text-xs text-muted-foreground">AWS 요금을 계산하고 최적화하고 있습니다</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <ScrollArea className="h-[600px]">
      <div className="p-6">
        {/* Invoice Header */}
        <div className="mb-6 flex items-start justify-between">
          <div>
            <h3 className="text-lg font-semibold text-foreground">월간 예상 비용</h3>
            <p className="text-xs text-muted-foreground">AWS 서울 리전 (ap-northeast-2) 기준</p>
          </div>
          <Badge className="bg-success/10 text-success border-success/20">
            <TrendingDown className="mr-1 h-3 w-3" strokeWidth={1.5} />
            최적화 가능
          </Badge>
        </div>

        {/* Cost Summary Cards */}
        <div className="mb-6 grid grid-cols-3 gap-4">
          <div className="rounded-xl border border-border/50 bg-secondary/20 p-4">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">현재 예상 비용</p>
            <p className="mt-1 text-2xl font-semibold text-foreground">
              ${costData.summary.totalMonthly.toFixed(2)}
              <span className="text-xs font-normal text-muted-foreground">/월</span>
            </p>
          </div>
          <div className="rounded-xl border border-border/50 bg-primary/5 p-4">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">최적화 후 비용</p>
            <p className="mt-1 text-2xl font-semibold text-primary">
              ${costData.summary.totalOptimized.toFixed(2)}
              <span className="text-xs font-normal text-muted-foreground">/월</span>
            </p>
          </div>
          <div className="rounded-xl border border-success/20 bg-success/5 p-4">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">절감 가능 비용</p>
            <p className="mt-1 text-2xl font-semibold text-success">
              ${costData.summary.totalSavings.toFixed(2)}
              <span className="text-xs font-normal text-success/70">/월 ({costData.summary.savingsPercent})</span>
            </p>
          </div>
        </div>

        <Separator className="mb-6 bg-border/30" />

        {/* Line Items */}
        <div className="space-y-0">
          <div className="mb-3 grid grid-cols-12 gap-4 text-[10px] uppercase tracking-wider text-muted-foreground">
            <div className="col-span-5">서비스</div>
            <div className="col-span-2 text-right">현재 비용</div>
            <div className="col-span-2 text-right">최적화 비용</div>
            <div className="col-span-3 text-right">절감률</div>
          </div>
          
          {costData.services.map((service, index) => (
            <div key={index}>
              <div className="grid grid-cols-12 gap-4 py-3 items-center">
                <div className="col-span-5">
                  <p className="text-sm font-medium text-foreground">{service.name}</p>
                  <p className="text-[11px] text-muted-foreground">{service.description}</p>
                </div>
                <div className="col-span-2 text-right">
                  <span className="text-sm text-foreground">${service.monthly.toFixed(2)}</span>
                </div>
                <div className="col-span-2 text-right">
                  <span className="text-sm text-primary font-medium">${service.optimized.toFixed(2)}</span>
                </div>
                <div className="col-span-3 text-right">
                  {service.savings !== "0%" ? (
                    <Badge variant="secondary" className="text-[10px] bg-success/10 text-success border-success/20">
                      {service.savings} 절감
                    </Badge>
                  ) : (
                    <span className="text-xs text-muted-foreground">-</span>
                  )}
                </div>
              </div>
              
              {service.recommendation && (
                <div className="mb-3 ml-4 flex items-center gap-2 rounded-lg bg-primary/5 px-3 py-2">
                  <AlertCircle className="h-3.5 w-3.5 text-primary" strokeWidth={1.5} />
                  <span className="text-[11px] text-primary">{service.recommendation}</span>
                </div>
              )}
              
              {index < costData.services.length - 1 && (
                <Separator className="bg-border/20" />
              )}
            </div>
          ))}
        </div>

        <Separator className="my-6 bg-border/30" />

        {/* Total */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="h-5 w-5 text-success" strokeWidth={1.5} />
            <div>
              <p className="text-sm font-medium text-foreground">연간 절감 예상</p>
              <p className="text-xs text-muted-foreground">최적화 권장사항 적용 시</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-semibold text-success">
              ${(costData.summary.totalSavings * 12).toFixed(2)}
              <span className="text-xs font-normal text-muted-foreground">/년</span>
            </p>
          </div>
        </div>

        {/* CTA */}
        <div className="mt-6 flex items-center justify-center rounded-xl border border-primary/20 bg-primary/5 p-4">
          <span className="text-sm text-foreground">최적화 적용하기</span>
          <ArrowRight className="ml-2 h-4 w-4 text-primary" strokeWidth={1.5} />
        </div>
      </div>
    </ScrollArea>
  )
}
